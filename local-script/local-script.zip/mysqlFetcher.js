const mysql = require("mysql2/promise");
const config = require("./config");

// 格式化数据，处理日期和大数字
function formatRow(row) {
  const formatted = {};
  for (const [key, value] of Object.entries(row)) {
    if (value instanceof Date) {
      formatted[key] = value.toISOString().slice(0, 19).replace('T', ' ');
    } else if (typeof value === 'bigint' || (typeof value === 'number' && !Number.isSafeInteger(value))) {
      formatted[key] = value.toString();
    } else {
      formatted[key] = value;
    }
  }
  return formatted;
}

async function fetchMysqlData() {
  if (!config.mysqlConfig || !config.mysqlConfig.tables || config.mysqlConfig.tables.length === 0) {
    return [];
  }

  let connection;
  const mysqlSnapshots = [];

  try {
    // 创建连接
    connection = await mysql.createConnection({
      host: config.mysqlConfig.host,
      port: config.mysqlConfig.port || 3306,
      user: config.mysqlConfig.user,
      password: config.mysqlConfig.password,
      database: config.mysqlConfig.database,
    });

    // 遍历每个表查询
    for (const tableName of config.mysqlConfig.tables) {
      try {
        const [rows] = await connection.execute(`SELECT * FROM ?? LIMIT 1000`, [tableName]);
        const formattedRows = rows.map(formatRow);
        mysqlSnapshots.push({
          tableName,
          data: formattedRows,
          updatedAt: Date.now()
        });
      } catch (tableError) {
        console.error(`查询表 ${tableName} 失败:`, tableError.message);
      }
    }

    return mysqlSnapshots;

  } catch (error) {
    console.error("连接 MySQL 失败:", error.message);
    return [];
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

module.exports = { fetchMysqlData };
