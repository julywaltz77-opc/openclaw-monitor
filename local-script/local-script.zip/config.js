// 默认配置，用户可根据实际情况修改
module.exports = {
  // Convex 配置
  convexUrl: "https://your-project-id.convex.cloud",
  uploadSecret: "your-custom-secret-key",
  
  // 上报配置
  reportInterval: 60000, // 上报间隔，单位毫秒（默认1分钟）
  retryCount: 3, // 上报失败重试次数
  retryInterval: 30000, // 重试间隔，单位毫秒（默认30秒）
  
  // Agent 路径配置，支持多个 Agent 目录
  agentPaths: [
    require("os").homedir() + "/.openclaw"
    // 可添加更多 Agent 路径："/path/to/another/agent"
  ],
  
  // MySQL 配置，不需要监控则留空
  mysqlConfig: {
    host: "localhost",
    port: 3306,
    user: "root",
    password: "",
    database: "",
    // 需要监控的表名列表
    tables: [
      // "table1", "table2"
    ]
  }
}
