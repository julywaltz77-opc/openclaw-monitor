const fetch = require("node-fetch");
const fs = require("fs");
const path = require("path");
const config = require("./config");

// 写入上报日志
function writeUploadLog(message, level = "info") {
  const logPath = path.join(__dirname, "logs", "upload.log");
  const logMessage = `[${new Date().toISOString()}] [${level}] ${message}\n`;
  console.log(logMessage.trim());
  fs.appendFileSync(logPath, logMessage);
}

// 格式化日期为 YYYY-MM-DD HH:mm:ss
function formatDate(timestamp) {
  return new Date(timestamp).toISOString().slice(0, 19).replace('T', ' ');
}

// 统一格式化数据
function formatData(data) {
  const { agents, tasks, taskLogs, mysqlSnapshots } = data;

  return {
    agents: agents.map(agent => ({
      ...agent,
      lastHeartbeat: formatDate(agent.lastHeartbeat)
    })),
    tasks: tasks.map(task => ({
      ...task,
      lastRunTime: task.lastRunTime ? formatDate(task.lastRunTime) : null,
      nextRunTime: task.nextRunTime ? formatDate(task.nextRunTime) : null
    })),
    taskLogs: taskLogs.map(log => ({
      ...log,
      timestamp: formatDate(log.timestamp)
    })),
    mysqlSnapshots: mysqlSnapshots.map(snapshot => ({
      ...snapshot,
      updatedAt: formatDate(snapshot.updatedAt)
    }))
  };
}

// 带重试的上报
async function uploadWithRetry(data, retries = config.retryCount || 3) {
  const formattedData = formatData(data);

  for (let i = 0; i < retries; i++) {
    try {
      writeUploadLog(`开始第 ${i+1} 次上报数据...`);
      
      const response = await fetch(`${config.convexUrl}/api/actions/reportData`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Upload-Secret": config.uploadSecret
        },
        body: JSON.stringify(formattedData),
        timeout: 30000
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`HTTP ${response.status}: ${error}`);
      }

      const result = await response.json();
      writeUploadLog(`上报成功，共上报：${result.count.agents}个Agent、${result.count.tasks}个任务、${result.count.taskLogs}条日志、${result.count.mysqlSnapshots}个MySQL快照`);
      return result;

    } catch (error) {
      const errorMsg = `上报失败（第 ${i+1} 次）: ${error.message}`;
      writeUploadLog(errorMsg, "error");
      
      if (i < retries - 1) {
        writeUploadLog(`等待 ${config.retryInterval/1000} 秒后重试...`);
        await new Promise(resolve => setTimeout(resolve, config.retryInterval || 30000));
      } else {
        writeUploadLog("重试次数用尽，上报失败", "error");
        throw error;
      }
    }
  }
}

module.exports = { upload: uploadWithRetry };
