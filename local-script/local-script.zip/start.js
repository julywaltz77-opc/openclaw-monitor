const fs = require("fs");
const path = require("path");
const agentMonitor = require("./agentMonitor");
const mysqlFetcher = require("./mysqlFetcher");
const convexUploader = require("./convexUploader");
const config = require("./config");

// 确保日志目录存在
const logDir = path.join(__dirname, "logs");
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true });
}

// 主上报函数
async function report() {
  try {
    console.log("开始采集数据...");
    
    // 采集 Agent、任务、日志数据
    const { agents, tasks, taskLogs } = await agentMonitor.collectAllAgentsData();
    console.log(`采集到 ${agents.length} 个 Agent、${tasks.length} 个任务、${taskLogs.length} 条日志`);

    // 采集 MySQL 数据
    let mysqlSnapshots = [];
    if (config.mysqlConfig && config.mysqlConfig.tables && config.mysqlConfig.tables.length > 0) {
      mysqlSnapshots = await mysqlFetcher.fetchMysqlData();
      console.log(`采集到 ${mysqlSnapshots.length} 个 MySQL 表快照`);
    }

    // 上报到 Convex
    await convexUploader.upload({ agents, tasks, taskLogs, mysqlSnapshots });
    console.log("数据上报成功");

  } catch (error) {
    console.error(`上报流程失败: ${error.message}`);
    console.error(error.stack);
  }
}

// 立即执行一次
report();

// 定时执行
setInterval(report, config.reportInterval || 60000);

console.log(`OpenClaw 监控脚本已启动，上报间隔：${config.reportInterval / 1000} 秒`);
