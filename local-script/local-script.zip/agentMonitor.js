const fs = require("fs");
const path = require("path");
const config = require("./config");

// 采集所有 Agent 数据
async function collectAllAgentsData() {
  const agents = [];
  const tasks = [];
  const taskLogs = [];

  for (const agentPath of config.agentPaths) {
    try {
      // 读取 Agent 状态
      const statusPath = path.join(agentPath, "status.json");
      if (fs.existsSync(statusPath)) {
        const statusData = JSON.parse(fs.readFileSync(statusPath, "utf8"));
        agents.push({
          id: statusData.id || path.basename(agentPath),
          name: statusData.name || path.basename(agentPath),
          status: statusData.status === "online" ? "online" : "offline",
          lastHeartbeat: statusData.lastHeartbeat || Date.now(),
          version: statusData.version || "unknown",
          model: statusData.model || "unknown"
        });
      }

      // 读取任务数据
      const tasksPath = path.join(agentPath, "tasks.json");
      if (fs.existsSync(tasksPath)) {
        const tasksData = JSON.parse(fs.readFileSync(tasksPath, "utf8"));
        const agentName = path.basename(agentPath);
        tasksData.forEach(task => {
          tasks.push({
            agentName,
            taskName: task.taskName,
            cron: task.cron,
            status: task.status,
            lastRunTime: task.lastRunTime || null,
            nextRunTime: task.nextRunTime || null
          });
        });
      }

      // 读取日志数据
      const logsDir = path.join(agentPath, "logs");
      if (fs.existsSync(logsDir)) {
        const logFiles = fs.readdirSync(logsDir)
          .filter(file => file.endsWith(".log"))
          .map(file => ({ file, mtime: fs.statSync(path.join(logsDir, file)).mtime }))
          .sort((a, b) => b.mtime - a.mtime)
          .slice(0, 5); // 最近5个日志文件

        const agentName = path.basename(agentPath);
        for (const logFile of logFiles) {
          const logContent = fs.readFileSync(path.join(logsDir, logFile.file), "utf8");
          const lines = logContent.split("\n").filter(line => line.trim()).slice(-100); // 每个文件取最近100条
          
          lines.forEach(line => {
            const match = line.match(/\[(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z)\] \[(\w+)\] \[(.*?)\] (.*)/);
            if (match) {
              taskLogs.push({
                agentName,
                taskName: match[3],
                status: match[2],
                message: match[4],
                timestamp: new Date(match[1]).getTime()
              });
            } else {
              taskLogs.push({
                agentName,
                taskName: "unknown",
                status: "info",
                message: line,
                timestamp: Date.now()
              });
            }
          });
        }
      }

    } catch (error) {
      console.error(`采集 Agent ${agentPath} 数据失败:`, error.message);
    }
  }

  return { agents, tasks, taskLogs };
}

module.exports = { collectAllAgentsData };
